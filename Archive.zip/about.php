<?php
  include_once 'includes/header.php';
?>

    <!-- Banner Section start -->
    <section class="aboutus">
      <div class="container">
        <div class="row mt-5">
          <div class="col-lg-12">
              <h1>Here will be About Us</h1>
          </div>
        </div>
      </div>
    </section>
    <!-- Banner Section end -->

<?php 
  include_once 'includes/doner_form.php';

  include_once 'includes/footer.php';
?>