<?php

class FrontPartProcess
{
    public function saveDonnerInfo(){

    }
}